#!/usr/bin/env bash
/opt/move/MoveLauncher
